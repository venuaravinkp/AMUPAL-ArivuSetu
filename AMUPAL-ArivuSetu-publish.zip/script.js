const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('.site-nav');

menuButton.addEventListener('click', () => {
  const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Open navigation' : 'Close navigation');
  navigation.classList.toggle('open', !isOpen);
});

navigation.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open navigation');
  });
});

document.querySelectorAll('[data-challenge]').forEach((button) => {
  button.addEventListener('click', () => {
    const hint = document.getElementById(`hint-${button.dataset.challenge}`);
    const showHint = hint.hidden;
    hint.hidden = !showHint;
    button.querySelector('span').textContent = showHint ? '−' : '＋';
    button.firstChild.textContent = showHint
      ? (button.dataset.challenge === 'search' ? 'Hide hint ' : 'Hide answer ')
      : (button.dataset.challenge === 'search' ? 'Show me a hint ' : 'Reveal the answer ');
  });
});

document.querySelectorAll('.video-frame').forEach((frame) => {
  frame.querySelector('.play-video').addEventListener('click', () => {
    const videoId = frame.dataset.video;
    const title = frame.dataset.title;
    const player = document.createElement('iframe');
    player.src = `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`;
    player.title = title;
    player.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
    player.referrerPolicy = 'strict-origin-when-cross-origin';
    player.allowFullscreen = true;
    player.setAttribute('loading', 'lazy');
    frame.replaceChildren(player);
  });
});

const quizForm = document.getElementById('quiz-form');
quizForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const answers = new FormData(quizForm);
  let score = 0;
  for (let number = 1; number <= 10; number += 1) {
    if (answers.get(`q${number}`) === '1') score += 1;
  }
  const answered = [...Array(10)].filter((_, index) => answers.has(`q${index + 1}`)).length;
  const result = document.getElementById('quiz-result');
  result.textContent = answered < 10
    ? `You answered ${answered} of 10. Try all questions to see your score.`
    : `Your score: ${score} out of 10. Review the answer key and discuss one new habit.`;
});

document.getElementById('compare-scores').addEventListener('click', () => {
  const before = Number(document.getElementById('score-before').value);
  const after = Number(document.getElementById('score-after').value);
  const result = document.getElementById('analysis-result');
  if (!Number.isInteger(before) || !Number.isInteger(after) || before < 0 || before > 10 || after < 0 || after > 10) {
    result.textContent = 'Enter both group scores as whole numbers from 0 to 10.';
    return;
  }
  const change = after - before;
  result.textContent = change > 0
    ? `Group score changed by +${change} point${change === 1 ? '' : 's'} out of 10. Discuss which skills improved and what still needs practice.`
    : change < 0
      ? `Group score changed by ${change} points out of 10. Review the questions and ask learners what was unclear.`
      : 'Group score stayed the same. Ask learners what support or extra practice would help.';
});

const guideText = 'Before you click, pause. Check who sent the message and where the link goes. Never share your password, one-time code, or private details. If a message feels urgent or strange, close it and ask a trusted teacher or adult. You are in control of what you share.';
document.getElementById('audio-play').addEventListener('click', () => {
  if (!('speechSynthesis' in window)) {
    document.getElementById('audio-play').textContent = 'Audio playback is not available in this browser. Read the guide text above.';
    return;
  }
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(new SpeechSynthesisUtterance(guideText));
});
document.getElementById('audio-stop').addEventListener('click', () => {
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
});

document.getElementById('summarize-feedback').addEventListener('click', () => {
  const comments = document.getElementById('feedback-input').value
    .split('\n').map((item) => item.trim()).filter(Boolean);
  const summary = document.getElementById('feedback-summary');
  if (comments.length === 0) {
    summary.textContent = 'Add at least one anonymous comment first.';
    return;
  }
  const themes = {
    practice: /practice|activity|try|hands.?on|time/i,
    access: /internet|offline|device|phone|video|load|data|connect/i,
    clarity: /clear|confus|explain|understand|language|translate/i,
    safety: /safe|privacy|password|scam|link/i,
    pace: /fast|slow|short|long|break|pace/i,
  };
  const counts = Object.entries(themes).map(([name, matcher]) => [name, comments.filter((comment) => matcher.test(comment)).length])
    .filter(([, count]) => count > 0).sort((a, b) => b[1] - a[1]);
  const actions = {
    practice: 'Protect enough time for pair practice and discussion.',
    access: 'Prepare an offline or printed alternative and test shared devices.',
    clarity: 'Simplify instructions and review translations with a fluent speaker.',
    safety: 'Revisit the safety example and trusted-help route.',
    pace: 'Adjust timing and include a short break.',
  };
  const priorities = counts.length ? counts.map(([name, count]) => `${name}: ${count} comment(s)`).join(' · ') : 'No common theme matched the simple keyword guide; facilitator review is needed.';
  const next = counts.length ? counts.slice(0, 2).map(([name]) => actions[name]).join(' ') : 'Read the comments manually and agree on one change with the facilitator team.';
  summary.textContent = `${comments.length} anonymous comment(s). Themes: ${priorities}. Suggested next step: ${next} This rule-based draft must be checked by a facilitator.`;
});

document.getElementById('print-toolkit').addEventListener('click', () => {
  const panels = [...document.querySelectorAll('.toolkit-item')];
  const previousState = panels.map((panel) => panel.open);
  panels.forEach((panel) => { panel.open = true; });
  window.addEventListener('afterprint', () => {
    panels.forEach((panel, index) => { panel.open = previousState[index]; });
  }, { once: true });
  window.print();
});
